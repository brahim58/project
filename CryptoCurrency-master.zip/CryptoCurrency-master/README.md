# Android Project for CryptoCurrency

Cette application a pour objectif de suivre le cours des cryptocurrency.

### Features:
- 1 activite permet de lister les CryptoCurrency en fonction de leur marketcap
- 1 autre activite permet d'afficher les informations supplementaires d'une crypto
- Utilisation de l'API de CoinMarketCap via retrofit2 pour recuperer les donnees des differentes cryptocurrency
- Mise en cache des donnees au cas ou l'on ne possede plus internet
- Utilisation d'un Toast pour prevenir l'utilisateur s'il ne possede pas internet
