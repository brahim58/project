package com.example.cryptocurrency.View;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.cryptocurrency.Controller.Information;
import com.example.cryptocurrency.Controller.MyAdapter;
import com.example.cryptocurrency.Modele.Api.MainController;
import com.example.cryptocurrency.Modele.Api.CryptoCurrency;
import com.example.cryptocurrency.Modele.Api.RestMarketcapResponse;
import com.example.cryptocurrency.R;

import java.util.List;

public class MainActivity extends AppCompatActivity {
    private static final String PREFS = "PREFS";
    // private CryptoCurrency mCrypto;
    private RecyclerView recyclerView;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager layoutManager;
    SharedPreferences sharedPreferences;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        sharedPreferences = getBaseContext().getSharedPreferences(PREFS, MODE_PRIVATE);

        MainController controller = new MainController(this, sharedPreferences);

        controller.start();


        recyclerView = findViewById(R.id.ListOfCrypto);




    }
    public void showCrypto(RestMarketcapResponse crypto) {
        recyclerView = findViewById(R.id.ListOfCrypto);
        recyclerView.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(this);

        recyclerView.setLayoutManager(layoutManager);


        mAdapter = new MyAdapter(crypto.getData());
        recyclerView.setAdapter(mAdapter);
    }
}
