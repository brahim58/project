package com.example.cryptocurrency.Controller;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import com.example.cryptocurrency.Modele.Api.CryptoCurrency;
import com.example.cryptocurrency.R;
import com.google.gson.Gson;

public class Information extends AppCompatActivity {

    private TextView symbol;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_information);
        symbol = (TextView)findViewById(R.id.displayName);

        CryptoCurrency crypto = new Gson().fromJson(getIntent().getStringExtra("json"), CryptoCurrency.class);
        symbol.setText(crypto.getName());


    }
}
