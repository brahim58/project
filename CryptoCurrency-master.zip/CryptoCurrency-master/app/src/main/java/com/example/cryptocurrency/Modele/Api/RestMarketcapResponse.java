package com.example.cryptocurrency.Modele.Api;


import java.util.List;

public class RestMarketcapResponse {
    private List<CryptoCurrency> data;

    public List<CryptoCurrency> getData() {
        return data;
    }
}