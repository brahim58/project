package com.example.cryptocurrency.Modele.Api;

import android.content.SharedPreferences;

import com.example.cryptocurrency.View.MainActivity;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.util.List;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class MainController{

    private static final String BASE_URL = "https://pro-api.coinmarketcap.com/";

    private MainActivity view;
    private SharedPreferences sharedPreferences;

    public MainController(MainActivity view, SharedPreferences sharedPreferences) {
        this.view = view;
        this.sharedPreferences = sharedPreferences;
    }

    public void start() {
        Gson gson = new GsonBuilder()
                .setLenient()
                .create();

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create(gson))
                .build();

        CoinmarketcapRestAPI RestAPI = retrofit.create(CoinmarketcapRestAPI.class);

        Call<RestMarketcapResponse> call = RestAPI.getCryptoCurrency();
        call.enqueue(new Callback<RestMarketcapResponse>() {

            @Override
            public void onResponse(Call<RestMarketcapResponse> call, Response<RestMarketcapResponse> response) {
                if(response.isSuccessful()) {
                    RestMarketcapResponse marketcapResponse = response.body();
                    String json = new Gson().toJson(marketcapResponse);
                    sharedPreferences
                            .edit()
                            .putString("json", json)
                            .apply();
                    view.showCrypto(marketcapResponse);
                } else {
                    String data = sharedPreferences.getString("json", null);
                    System.out.println(response.errorBody());
                    if(data.length() != 0){

                        view.showCrypto(new Gson().fromJson(data, RestMarketcapResponse.class));

                    }
                }
            }

            @Override
            public void onFailure(Call<RestMarketcapResponse> call, Throwable t) {
                String data = sharedPreferences.getString("json", null);
                if(data.length() != 0){
                    RestMarketcapResponse response = new Gson().fromJson(data, RestMarketcapResponse.class);
                    System.out.println(response);
                    view.showCrypto(response);

                }
                t.printStackTrace();
            }
        });

    }


}