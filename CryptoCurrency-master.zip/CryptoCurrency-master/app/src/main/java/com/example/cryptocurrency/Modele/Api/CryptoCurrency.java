package com.example.cryptocurrency.Modele.Api;

import org.json.JSONException;
import org.json.JSONObject;

public class CryptoCurrency {
    private int id;
    private String name;
    private String symbol;

    private Quote quote;

    public Quote getQuote() {
        return quote;
    }

    public void setQuote(Quote quote) {
        this.quote = quote;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSymbol() {
        return symbol;
    }

    public void setSymbol(String symbol) {
        this.symbol = symbol;
    }

//    public String toJSON(){
//
//        JSONObject jsonObject= new JSONObject();
//        try {
//            jsonObject.put("id", getId());
//            jsonObject.put("name", getName());
//            jsonObject.put("symbol", getSymbol());
//            jsonObject.put("price", getQuote().getUSD().getPrice());
//            jsonObject.put("market_cap", getQuote().getUSD().getMarket_cap());
//            jsonObject.put("change_24h", getQuote().getUSD().getPercent_change_24h());
//            jsonObject.put("change_7d", getQuote().getUSD().getPercent_change_7d());
//
//            return jsonObject.toString();
//        } catch (JSONException e) {
//            e.printStackTrace();
//            return "";
//        }
//
//    }

}
