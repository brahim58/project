package com.example.cryptocurrency.Modele.Api;

public class Quote {
    private Usd USD;

    public Usd getUSD() {
        return USD;
    }

    public void setUSD(Usd USD) {
        this.USD = USD;
    }
}
