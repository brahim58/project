package com.example.cryptocurrency.Controller;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;

import com.example.cryptocurrency.Modele.Api.CryptoCurrency;
import com.example.cryptocurrency.R;
import com.example.cryptocurrency.View.MainActivity;
import com.google.gson.Gson;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.ViewHolder> {  //implements Filterable {
    private List<CryptoCurrency> values;
    private View.OnClickListener onItemClickListener;
    private ArrayList mFilteredList;



    public MyAdapter(List<CryptoCurrency> myDataset) {
        values = myDataset;
    }

    // Create new views (invoked by the layout manager)
    @Override
    public MyAdapter.ViewHolder onCreateViewHolder(ViewGroup parent,
                                                   int viewType) {
        // create a new view
        LayoutInflater inflater = LayoutInflater.from(
                parent.getContext());
        View v =
                inflater.inflate(R.layout.recycler_view_item, parent, false);
        // set the view's size, margins, paddings and layout parameters
        ViewHolder vh = new ViewHolder(v);
        return vh;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {
        final CryptoCurrency currency = values.get(position);
        holder.txtHeader.setText(currency.getSymbol());
        holder.txtHeader.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent informationIntent = new Intent(v.getContext(), Information.class);
                informationIntent.putExtra("json", new Gson().toJson(currency));


                v.getContext().startActivity(informationIntent);
            }
        });

        holder.txtFooter.setText(currency.getName()+" : "+ currency.getQuote().getUSD().getPrice()+"$");
    }

    // Return the size of your dataset (invoked by the layout manager)
    @Override
    public int getItemCount() {
        return values.size();
    }

//    @Override
//    public Filter getFilter() {
//        return new Filter() {
//            @Override
//            protected FilterResults performFiltering(CharSequence charSequence) {
//
//                String charString = charSequence.toString();
//
//                if (charString.isEmpty()) {
//
//                    mFilteredList = mArrayList;
//                } else {
//
//                    ArrayList<AndroidVersion> filteredList = new ArrayList<>();
//
//                    for (AndroidVersion androidVersion : mArrayList) {
//
//                        if (androidVersion.getApi().toLowerCase().contains(charString) || androidVersion.getName().toLowerCase().contains(charString) || androidVersion.getVer().toLowerCase().contains(charString)) {
//
//                            filteredList.add(androidVersion);
//                        }
//                    }
//
//                    mFilteredList = filteredList;
//                }
//
//                FilterResults filterResults = new FilterResults();
//                filterResults.values = mFilteredList;
//                return filterResults;
//            }
//
//            @Override
//            protected void publishResults(CharSequence charSequence, FilterResults filterResults) {
//                mFilteredList = (ArrayList<AndroidVersion>) filterResults.values;
//                notifyDataSetChanged();
//            }
//        };
//    }


    public class ViewHolder extends RecyclerView.ViewHolder {
        public TextView txtHeader;
        public TextView txtFooter;
        public View layout;

        public ViewHolder(View v) {
            super(v);
            layout = v;
            txtHeader = (TextView) v.findViewById(R.id.CryptoName);
            txtFooter = (TextView) v.findViewById(R.id.description);
            itemView.setTag(this);
            itemView.setOnClickListener(onItemClickListener);
        }
    }


//    public void add(int position, CryptoCurrency item) {
//        values.add(position, item);
//        notifyItemInserted(position);
//    }
//
//    public void remove(int position) {
//        values.remove(position);
//        notifyItemRemoved(position);
//    }


}