package com.example.cryptocurrency.Modele.Api;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Headers;

public interface CoinmarketcapRestAPI {

    @Headers("X-CMC_PRO_API_KEY:6f6d551d-5fbb-40c7-a79f-5370bd8f0c84")

    @GET("/v1/cryptocurrency/listings/latest")
    Call<RestMarketcapResponse> getCryptoCurrency();
}